// Tue Feb 14 23:29:46 EST 2017 
import java.io.*;
import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;
import org.junit.Test; // fixes some compile problems with annotations

public class P3Tests {
  public static void main(String args[]) {
    org.junit.runner.JUnitCore.main("SpellCheckerTests",
                                    "AutomaticSCTests",
                                    "InteractiveSCTests",
                                    "PersonalSCTests");
  } 
}

