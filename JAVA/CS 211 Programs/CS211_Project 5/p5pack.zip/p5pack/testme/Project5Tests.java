import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;

import modepkg.*;

public class Project5Tests {
  public static void main(String args[]){
    org.junit.runner.JUnitCore.main("Project5Tests");
  }
  
  // Eliminate this test after you get the hang of things
  @Test public void example(){
    assertEquals(5,5);
    assertFalse(5==6);
    assertTrue(6==6);
  }  

}
