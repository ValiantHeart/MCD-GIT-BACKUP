#!/bin/bash
# set -x                          # echo on

for i in {1..13}; do
    echo --------------------------
    echo "Implementation $i"
    javac -cp .:junit-cs211.jar:imp$i *.java
    java -cp .:junit-cs211.jar:imp$i Project5Tests
done | grep -e "Tests run\|Implementation\|OK "
