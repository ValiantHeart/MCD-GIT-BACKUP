import java.io.*;
import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;
import org.junit.Test; // fixes some compile problems with annotations

public class ArraySetTests{

  public static void main(String args[]) {
    org.junit.runner.JUnitCore.main("ArraySetTests");
  }

  @Test public void constructor1(){
    ArraySet<String> a = new ArraySet<String>();
    assertEquals(0, a.size());
    assertEquals("[]", a.toString());
  }
  @Test public void constructor2(){
    ArraySet<Integer> a = new ArraySet<Integer>(5);
    assertEquals(0, a.size());
  }
  @Test public void containsNothing2(){
    ArraySet<String> a = new ArraySet<String>();
    assertFalse(a.contains("hi"));
    assertFalse(a.contains("bye"));
    assertFalse(a.contains("Blackbird"));
  }

  // ADD ADDITIONAL TESTS HERE


}
