public class Balanced
{
	public static boolean isBalanced(String s)
	{
		int left_parens = 0;
		int right_parens = 0;

		for (int i = 0; i < s.length(); i++)
		{
			if (s.charAt(i) == '(')
			{
				left_parens++;
			}

			else if (s.charAt(i) == ')')
			{
				right_parens++;
			}

			else
			{
				throw new RuntimeException("only parenthesis characters allowed");
			}
		}
		
				boolean balanced = true;
		
/*  		if (s.charAt(0) == ')' && length(s)> 0)
		{
			balanced = false;
		}  */
		return left_parens == right_parens && balanced == true;
	}
}