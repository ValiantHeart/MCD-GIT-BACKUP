import java.util.*;
public class ALUtils{
  // Creates a copy of the parameter a. Reverses the order of elements
  // in the copy and returns the reversed copy. Assumes a is non-null.
  public static ArrayList<String> reverse(ArrayList<String> a){
    // YOUR DEFINITION HERE 


  }

  // Creates a copy of the given ArrayList a and rotates the copy to
  // the right by the given shift.  Elements at high indicies wrap
  // around to lower indices.  Assumes parameter a is non-null and
  // that shift is a non-negative number. Returns the rotated copy.
  public static ArrayList<Integer> rotate(ArrayList<Integer> a, int shift){
    // YOUR DEFINITION HERE 

  }


}
